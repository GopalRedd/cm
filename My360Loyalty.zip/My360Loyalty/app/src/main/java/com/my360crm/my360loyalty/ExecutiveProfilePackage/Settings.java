package com.my360crm.my360loyalty.ExecutiveProfilePackage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.StartEmployeecamera;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Settings extends AppCompatActivity {


    Button addorchange, resizecam;
    AlertDialog.Builder alertDialog;
    ImageView imageView,imageView1;
    private static int RESULT_LOAD_IMAGE = 1;
    private Uri mImageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        addorchange = findViewById(R.id.addorcancel);
        resizecam = findViewById(R.id.resizecamera);
        imageView = findViewById(R.id.modifiy);
        imageView1 = findViewById(R.id.modifiy1);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String mImageUri = preferences.getString("image", null);

        if (mImageUri != null) {
            imageView1.setImageURI(Uri.parse(mImageUri));
        } else
            {
            imageView1.setImageResource(R.color.white);
        }

        addorchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent;
                if (Build.VERSION.SDK_INT < 19) {
                    intent = new Intent(Intent.ACTION_GET_CONTENT);
                } else {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                }
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 0);
            }
        });

        resizecam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomdialog();
            }
        });


    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    private void showCustomdialog() {


        final String names[] = {"High", "Meduim", "Low", "Default", "Cancel"};
        alertDialog = new AlertDialog.Builder(Settings.this);
        LayoutInflater inflater = getLayoutInflater();
        View convertView = (View) inflater.inflate(R.layout.custom_alert_dialog, null);
        alertDialog.setView(convertView);
        ListView lv = (ListView) convertView.findViewById(R.id.lv);
        /*ArrayAdapter<String> adapter = new  ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,names);
         */
        final AlertDialog alert = alertDialog.create();
        MyAdapter myadapter = new MyAdapter(getApplication(), R.layout.alertlist_item_text, names);

        lv.setAdapter(myadapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 4) {
                    alert.cancel();
                } else {

                    circularprogresssdialog.showDialog(Settings.this, "", "");
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            circularprogresssdialog.dismissdialog();
                            alert.cancel();
                            startActivity(new Intent(Settings.this, StartEmployeecamera.class));
                            finish();

                        }
                    }, 1000);

                }
            }
        });
        alert.show();


    }


    private class ViewHolder {

        TextView tvSname;

    }

    private class MyAdapter extends ArrayAdapter<String> {

        LayoutInflater inflater;

        Context myContext;

        List<String> newList;

        public MyAdapter(Context context, int resource, String[] list) {

            super(context, resource, list);

            // TODO Auto-generated constructor stub

            myContext = context;

            newList = Arrays.asList(list);

            inflater = LayoutInflater.from(context);

        }

        @Override

        public View getView(final int position, View view, ViewGroup parent) {

            final ViewHolder holder;

            if (view == null) {

                holder = new ViewHolder();

                view = inflater.inflate(R.layout.alertlist_item_text, null);

                holder.tvSname = (TextView) view.findViewById(R.id.item);

                view.setTag(holder);

            } else {

                holder = (ViewHolder) view.getTag();

            }

            holder.tvSname.setText(newList.get(position).toString());

            return view;

        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 0 && resultCode == RESULT_OK && null != data) {


            if(data != null)
            {

                mImageUri = data.getData();


                SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("image", String.valueOf(mImageUri));
                editor.commit();

                imageView1.setImageURI(mImageUri);
                imageView1.invalidate();

            }





/*

            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            imageView1.setVisibility(View.VISIBLE);
            imageView1.setImageBitmap(BitmapFactory.decodeFile(picturePath));
*/

        }
    }


}
