package com.my360crm.my360loyalty.CustomersPackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.my360crm.my360loyalty.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Transactions_List_Adapter extends BaseAdapter {
    private Context context;
    private ArrayList<Transaction_Data_Model> dataModelArrayList;


    public Transactions_List_Adapter(Context context, ArrayList<Transaction_Data_Model> dataModelArrayList) {
        this.context = context;
        this.dataModelArrayList = dataModelArrayList;
    }
    @Override
    public int getViewTypeCount() {
        if(getCount() > 0){
            return getCount();
        }else{
            return super.getViewTypeCount();
        }
    }
    @Override
    public int getItemViewType(int position) {

        return position;
    }
    @Override
    public int getCount() {
        return dataModelArrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return dataModelArrayList.get(position);
    }


    @Override
    public long getItemId(int position) {
        return 0;
    }


    @Override
    public View getView(int position, View convertview, ViewGroup parent) {

        ViewHolder holder;

        if(convertview == null)
        {
            holder = new ViewHolder();
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertview = layoutInflater.inflate(R.layout.transaction_layout,null,true);

            holder.imageView = convertview.findViewById(R.id.imageView);
            holder.points = convertview.findViewById(R.id.points);
            holder.partner = convertview.findViewById(R.id.textViewpartner);
            holder.member = convertview.findViewById(R.id.textViewmember);
            holder.transaxationid = convertview.findViewById(R.id.textViewtransaction);
            holder.timestamp = convertview.findViewById(R.id.textViewtime);

            convertview.setTag(holder);



        } else
        {
            holder = (ViewHolder)convertview.getTag();
        }

        if(dataModelArrayList.get(position).getImageurl().isEmpty())
        {
        holder.imageView.setImageResource(R.drawable.noimage);
        }else
            {
            Picasso.get().load(dataModelArrayList.get(position).getImageurl()).into(holder.imageView);
          }
        holder.points.setText("Points: "+dataModelArrayList.get(position).getPoints());
        holder.partner.setText("Partner: "+dataModelArrayList.get(position).getPartner());
        holder.member.setText("Member: "+dataModelArrayList.get(position).getMember());
        holder.transaxationid.setText("Transaction: "+dataModelArrayList.get(position).getTransaxtionid());
        holder.timestamp.setText("Time: "+dataModelArrayList.get(position).getTimestamp());

        return convertview;
    }

    private class ViewHolder {

        TextView points,partner,member,transaxationid,timestamp;
        ImageView imageView;

    }
}
