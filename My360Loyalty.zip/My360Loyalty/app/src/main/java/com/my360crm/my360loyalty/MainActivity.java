package com.my360crm.my360loyalty;

import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.crashlytics.android.Crashlytics;
import com.my360crm.my360loyalty.CameraPackage.ExecutiveCamera;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;

import java.util.Objects;

import io.fabric.sdk.android.Fabric;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    public void clickme(View view)
    {
        circularprogresssdialog.showDialog(MainActivity.this,"","");
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                circularprogresssdialog.dismissdialog();
                startActivity(new Intent(MainActivity.this, ExecutiveCamera.class));
                finish();
            }
        },2000);

    }

}
