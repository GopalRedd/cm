package com.my360crm.my360loyalty.CustomersPackage;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.StartEmployeecamera;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class NewCustomerActivity extends androidx.appcompat.app.AppCompatActivity {


    private static final String TAG = NewCustomerActivity.class.getSimpleName() ;
    TextInputEditText firstname,lastname,email,phonenum,accountnum,cardid;
    Button registernow;
    Bundle bundle;
    ImageView user_profile_photo;
    String cd;
    String an;
    TextView cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_customer);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        bundle = getIntent().getExtras();
        assert bundle != null;
        String status = bundle.getString("status");
        String userstatus = bundle.getString("userstatus");
        final String faceid = bundle.getString("faceid");
        final String faceurl = bundle.getString("faceurl");
        Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "userstatus " + userstatus + "\n" + "faceid " + faceid + "\n" + "faceurl " + faceurl + "\n" + "===========================\n");

        firstname = findViewById(R.id.fnameedit);
        lastname = findViewById(R.id.lnameedit);
        email = findViewById(R.id.emailedt);
        phonenum = findViewById(R.id.phoneedt);
        registernow = findViewById(R.id.registernow);
        user_profile_photo = findViewById(R.id.reguser_profile_photo);

        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                Log.d("DEBUG", "onBitmapLoaded");
                //progress_bar.setVisibility(View.GONE);
                user_profile_photo.setImageBitmap(getCircularBitmap(bitmap));
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                Log.d("DEBUG", "onBitmapFailed");
            }


            @Override
            public void onPrepareLoad(Drawable drawable) {
                Log.d("DEBUG", "onPrepareLoad");
            }
        };

        Picasso.get().load(faceurl).into(mTarget);
        user_profile_photo.setTag(mTarget);

        registernow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fn = Objects.requireNonNull(firstname.getText()).toString();
                String ln =  Objects.requireNonNull(lastname.getText()).toString();
                String em =  Objects.requireNonNull(email.getText()).toString();
                String pn =  Objects.requireNonNull(phonenum.getText()).toString();
                 an =  "111111";
                 cd =  "card1";
                if(fn.isEmpty())
                {
                    firstname.setError("First Name is must");
                } else if(ln.isEmpty())
                {
                    lastname.setError("Last Name is must");
                }else if(em.isEmpty())
                {
                    email.setError("Email is must");
                }else if(pn.length()<10)
                {
                    phonenum.setError("Phone number is must");
                } /*else if(an.length()<0)
                {
                    accountnum.setError("Account Number is must");
                } else if(cd.length()<0)
                {
                    cardid.setError("Card id is must");
                }*/ else
                {
                    // faceid is must
                    Uploadtoserver(fn,ln,em,pn,an,cd,faceid,faceurl);
                }

            }
        });

    }
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(NewCustomerActivity.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(NewCustomerActivity.this,StartEmployeecamera.class));
                    finish();
                }
            }, 1000);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        circularprogresssdialog.showDialog(NewCustomerActivity.this,"","");
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                startActivity(new Intent(NewCustomerActivity.this,StartEmployeecamera.class));
                finish();

            }
        },1000);

    }


    private void Uploadtoserver(final String fn, final String ln, final String em, final String pn, final String an, final String cd, final String faceid, final String faceurl) {
        circularprogresssdialog.showDialog(NewCustomerActivity.this,"","");

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:8000/api/registerMember", new Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Log.i(TAG,response);
                try
                {
                    circularprogresssdialog.dismissdialog();
                    JSONObject jsonObject = new JSONObject(response);
                        boolean status = jsonObject.getBoolean("success");
                        if (status)
                        {
                            Snackbar.make(findViewById(android.R.id.content), "User Registerd With Us Successfully Thank you ! ", Snackbar.LENGTH_LONG).show();
                            new Handler().postDelayed(new Runnable()
                            {
                                @Override
                                public void run()
                                {
                                    startActivity(new Intent(NewCustomerActivity.this, StartEmployeecamera.class));
                                    finish();
                                }
                            }, 3000);

                        }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Snackbar.make(findViewById(android.R.id.content), e.getMessage(), Snackbar.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error)
            {

                circularprogresssdialog.dismissdialog();
                //parseVolleyError(error);
                Log.i(TAG,error.toString());
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again ",Snackbar.LENGTH_LONG).show();

            }
        })
        {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();

                params.put("firstname",fn);
                params.put("lastname",ln);
                params.put("email",em);
                params.put("phonenumber",pn);
                params.put("faceid",faceid);
                params.put("faceURL",faceurl);

                /*params.put("firstname",fn);*/ // For faceid

                return params;
            }
        };stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        Volley.newRequestQueue(this).add(stringRequest);

    }

    private void parseVolleyError(VolleyError error) {
        try {
            String responseBody = new String(error.networkResponse.data, "utf-8");
            JSONObject data = new JSONObject(responseBody);
            JSONArray errors = data.getJSONArray("errors");
            JSONObject jsonMessage = errors.getJSONObject(0);
            String message = jsonMessage.getString("message");
            Log.i(TAG,message);
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        } catch (JSONException e) {
        } catch (UnsupportedEncodingException errorr) {
        }
    }

}
