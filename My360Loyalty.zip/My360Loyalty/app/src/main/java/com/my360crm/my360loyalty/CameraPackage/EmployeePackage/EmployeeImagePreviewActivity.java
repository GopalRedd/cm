package com.my360crm.my360loyalty.CameraPackage.EmployeePackage;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.util.SparseArray;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.vision.Frame;
import com.google.android.gms.vision.face.Face;
import com.google.android.gms.vision.face.FaceDetector;
import com.google.android.gms.vision.face.Landmark;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360loyalty.CameraPackage.ExecutiveCamera;
import com.my360crm.my360loyalty.CameraPackage.ImagePreview;
import com.my360crm.my360loyalty.CameraPackage.RegisterActivation;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.CustomersPackage.NewCustomerActivity;
import com.my360crm.my360loyalty.CustomersPackage.OldCustomerActivity;
import com.my360crm.my360loyalty.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360loyalty.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class EmployeeImagePreviewActivity extends AppCompatActivity {

    private static final String TAG = EmployeeImagePreviewActivity.class.getSimpleName();
    ImageView person_image ;
    String stingimage;
    Bitmap b;
    Bundle bundle;
    boolean isSmiling;
    float rightEye;
    float leftEye;
    Canvas canvas;
    final double SMILING_THRESHOLD = 0.2;
    final double WINK_THRESHOLD = 0.4;
    private FaceDetector detector;
    String lineEnd = "rn";
    String twoHyphens = "–";
    String boundary = "*****";
    private byte[] multipartBody;
    private String mimeType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_image_preview);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Log.i(TAG,TAG);
        person_image = findViewById(R.id.emp_person_image);
        detector = new FaceDetector.Builder(getApplicationContext())
                .setTrackingEnabled(false)
                .setLandmarkType(FaceDetector.ALL_LANDMARKS)
                .setClassificationType(FaceDetector.ALL_CLASSIFICATIONS)
                .setProminentFaceOnly(true)
                .build();

        if(getIntent().hasExtra("image"))
        {
            b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"),0,getIntent()
                            .getByteArrayExtra("image").length);


            ProcessImage(b);
            person_image.setImageBitmap(b);


            //upload image if you want from here

        }
    }

    private void ProcessImage(final Bitmap b) {

        if (detector.isOperational() && b != null) {
            Bitmap  editedBitmap = Bitmap.createBitmap(b.getWidth(), b
                    .getHeight(), b.getConfig());
            float scale = getResources().getDisplayMetrics().density;
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setColor(Color.GREEN);
            paint.setTextSize((int) (16 * scale));
            paint.setShadowLayer(1f, 0f, 1f, Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(6f);
            Canvas canvas = new Canvas(editedBitmap);
            canvas.drawBitmap(b, 0, 0, paint);
            Frame frame = new Frame.Builder().setBitmap(b).build();
            SparseArray<Face> faces = detector.detect(frame);
            // txtSampleDesc.setText(null);
            for (int index = 0; index < faces.size(); ++index) {
                Face face = faces.valueAt(index);
                canvas.drawRect(
                        face.getPosition().x,
                        face.getPosition().y,
                        face.getPosition().x + face.getWidth(),
                        face.getPosition().y + face.getHeight(), paint);

/*
            canvas.drawText("Face " + (index + 1), face.getPosition().x + face.getWidth(), face.getPosition().y + face.getHeight(), paint);

            txtSampleDesc.setText(txtSampleDesc.getText() + "FACE " + (index + 1) + "\n");
            txtSampleDesc.setText(txtSampleDesc.getText() + "Smile probability:" + " " + face.getIsSmilingProbability() + "\n");
            txtSampleDesc.setText(txtSampleDesc.getText() + "Left Eye Is Open Probability: " + " " + face.getIsLeftEyeOpenProbability() + "\n");
            txtSampleDesc.setText(txtSampleDesc.getText() + "Right Eye Is Open Probability: " + " " + face.getIsRightEyeOpenProbability() + "\n\n");
*/



                Log.i(TAG,"FACE " + (index + 1) + "\n");
                Log.i(TAG,"Smile probability:" + " " + face.getIsSmilingProbability() + "\n");
                Log.i(TAG,"Left Eye Is Open Probability: " + " " + face.getIsLeftEyeOpenProbability() + "\n");
                Log.i(TAG,"Right Eye Is Open Probability: " + " " + face.getIsRightEyeOpenProbability() + "\n\n");

                rightEye = face.getIsRightEyeOpenProbability();
                leftEye  = face.getIsLeftEyeOpenProbability();
                isSmiling = face.getIsSmilingProbability() > SMILING_THRESHOLD;

                for (Landmark landmark : face.getLandmarks())
                {
                    int cx = (int) (landmark.getPosition().x);
                    int cy = (int) (landmark.getPosition().y);
                    PointF leftEyePoint = null;
                    PointF rightEyePoint = null;
                    PointF leftmouth = null;
                    PointF rightmouth = null;

                    switch (landmark.getType()){
                        case Landmark.LEFT_EYE:
                            leftEyePoint = landmark.getPosition();
                            Log.i(TAG,"left eye"+leftEyePoint.toString());
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.RIGHT_EYE:
                            rightEyePoint = landmark.getPosition();
                            Log.i(TAG,"rite eye"+rightEyePoint.toString());
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.BOTTOM_MOUTH:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.LEFT_MOUTH:
                            leftmouth = landmark.getPosition();
                            Log.i(TAG,"leftmouth"+leftmouth.toString());
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.RIGHT_MOUTH:
                            rightmouth = landmark.getPosition();
                            Log.i(TAG,"rite mouth"+rightmouth.toString());
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.NOSE_BASE:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.LEFT_CHEEK:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.RIGHT_CHEEK:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.LEFT_EAR:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.LEFT_EAR_TIP:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.RIGHT_EAR:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                        case Landmark.RIGHT_EAR_TIP:
                            //drawPoint(canvas, landmark.getPosition());
                            break;
                    }
                    if(leftEyePoint == null && rightEyePoint ==null && leftmouth == null && rightmouth == null)
                    {
                        Log.i(TAG,"eyes not found");

                    } else
                    {
                        Log.i(TAG,"eyes  found");

                    }

//                canvas.drawCircle(cx, cy, 1, paint);
                }

            }

            if (faces.size() == 1)
            {
                Log.i(TAG,"Checking started ");
                if (leftEye > WINK_THRESHOLD || rightEye > WINK_THRESHOLD && isSmiling  )
                {
                    Log.i(TAG," yes Full face  Crossed ");
                    person_image.setImageBitmap(editedBitmap);
                    // ImageUploadtoserver(b);

                    //UPloadtoNextScreen(editedBitmap);
                    Imageuploadtoserver(editedBitmap);
                    Log.i(TAG, "No of Faces Detected: " + " " + String.valueOf(faces.size()));

                }else
                {
                    Log.i(TAG,"Back to 1");
                    //getIntent().removeExtra("image");
                    getIntent().setAction("");
                    setIntent(null);
                    Intent intent = new Intent(EmployeeImagePreviewActivity.this,EmployeeCamera.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);

                }


            } else  {



                Log.i(TAG,"Scan Failed: Found nothing to scan");
                Log.i(TAG,"No Face Found");
                Log.i(TAG,"Back to 1");
                //getIntent().removeExtra("image");
                getIntent().setAction("");
                setIntent(null);

                new AlertDialog.Builder(EmployeeImagePreviewActivity.this)
                        .setTitle("Alert")
                        .setMessage("My360Loyalty will Not allow Multiple Faces")
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(EmployeeImagePreviewActivity.this,EmployeeCamera.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        }).show();






            }

        } else {
            Log.i(TAG,"Could not set up the detector!");
        }
    }

    private void Imageuploadtoserver(final Bitmap editedBitmap) { //https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/AWS.php   http://13.236.116.157:8000/post/

        circularprogresssdialog.showDialog(EmployeeImagePreviewActivity.this,"","");
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "http://52.62.15.123:8000/post", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                try {
                    circularprogresssdialog.dismissdialog();
                    JSONObject obj = new JSONObject(new String(response.data));
                    //Toast.makeText(getApplicationContext(), obj.getString("message"), Toast.LENGTH_SHORT).show();
                    String status = obj.getString("status");
                    String userstatus = obj.getString("userStatus");
                    String faceid = obj.getString("faceID");
                    String faceurl = obj.getString("faceurl");
                    Log.i(TAG,"********************************************");
                    Log.i(TAG,"status "+status);
                    Log.i(TAG,"userstatus "+userstatus);
                    Log.i(TAG,"faceid "+faceid);
                    Log.i(TAG,"faceurl "+faceurl);
                    Log.i(TAG,obj.toString());
                    Log.i(TAG,"********************************************");

                    //UPloadtoNextScreen(editedBitmap);
                    //checkwhichtypeuser


                 if(status.equals("success") && userstatus.equals("OldUser") && !faceid.isEmpty() && !faceurl.isEmpty())
                 {//do one operation which is get all details of user

                     UPloadtoNextScreen(editedBitmap,status,userstatus,faceid,faceurl);

                 } else if(status.equals("success") && userstatus.equals("NewUser") && !faceid.isEmpty() && !faceurl.isEmpty())
                 {
                     UploadtoNewCustomerActivity(editedBitmap,status,userstatus,faceid,faceurl);
                     //do one operation which is to ask for user details and upload them to server
                 } else if(status.equals("success") && userstatus.equals("OldUser")  )
                 {
                    // Not Human
                     Snackbar.make(findViewById(android.R.id.content),"Face is Not Clarity ",Snackbar.LENGTH_LONG).show();

                     new Handler().postDelayed(new Runnable() {
                         @Override
                         public void run() {

                             startActivity(new Intent(EmployeeImagePreviewActivity.this,StartEmployeecamera.class));
                             finish();
                         }
                     },3000);

                 }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Snackbar.make(findViewById(android.R.id.content),e.getMessage(),Snackbar.LENGTH_LONG).show();
                    startActivity(new Intent(EmployeeImagePreviewActivity.this,EmployeeCamera.class));
                    finish();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


                NetworkResponse response = error.networkResponse;
                String errorMsg = "";
                if(response != null && response.data != null){
                    String errorString = new String(response.data);
                    Log.i("log error", errorString);
                }

                circularprogresssdialog.dismissdialog();
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again  ",Snackbar.LENGTH_LONG).show();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        startActivity(new Intent(EmployeeImagePreviewActivity.this,StartEmployeecamera.class));
                        finish();
                    }
                },1000);


                Log.e(TAG,"Something error "+error.getLocalizedMessage());
            }
        })

        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                //params.put("tags", tags);
                return params;
            }


            /*
             * Here we are passing image by renaming it with a unique name
             * */
            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("file", new DataPart(imagename + ".jpeg", getFileDataFromDrawable(editedBitmap)));
                return params;
            }
        }; multipartRequest.setShouldCache(false);
        multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        Volley.newRequestQueue(this).add(multipartRequest);
    }

    private void parseVolleyError(VolleyError error)
    {

        try {
            String responseBody = new String(error.networkResponse.data, "utf-8");
            JSONObject data = new JSONObject(responseBody);
            JSONArray errors = data.getJSONArray("errors");
            JSONObject jsonMessage = errors.getJSONObject(0);
            String message = jsonMessage.getString("message");
            Log.i(TAG,message);
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
        } catch (JSONException e) {
        } catch (UnsupportedEncodingException errorr) {
        }


    }


    /* New User Activity writeen by GS */


    private void UploadtoNewCustomerActivity(Bitmap editedBitmap, String status, String userstatus, String faceid, String faceurl) {

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        editedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        Intent in1 = new Intent(EmployeeImagePreviewActivity.this, NewCustomerActivity.class);
        in1.putExtra("image",byteArray);
        in1.putExtra("status",status);
        in1.putExtra("userstatus",userstatus);
        in1.putExtra("faceid",faceid);
        in1.putExtra("faceurl",faceurl);
        startActivity(in1);
        finish();


    }

    /* Old User Activity writeen by GS */

    private void UPloadtoNextScreen(Bitmap editedBitmap, String status, String userstatus, String faceid, String faceurl)
    {
//OldCustomerActivity
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        editedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        Intent in1 = new Intent(EmployeeImagePreviewActivity.this, OldCustomerActivity.class);
        in1.putExtra("image",byteArray);
        in1.putExtra("status",status);
        in1.putExtra("userstatus",userstatus);
        in1.putExtra("faceid",faceid);
        in1.putExtra("faceurl",faceurl);
        startActivity(in1);
        finish();

    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }
    private void drawPoint(Canvas canvas, PointF point) {

        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(8);
        paint.setStyle(Paint.Style.STROKE);
        float x = point.x;
        float y = point.y;
        canvas.drawCircle(x, y, 1, paint);
    }

    public byte[] getFileDataFromDrawable(Bitmap bitmap) {

        if(bitmap != null)
        {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
            Log.i(TAG,byteArrayOutputStream.toByteArray().toString());
            return byteArrayOutputStream.toByteArray();

        } else
        {
            Log.i(TAG,"Bitmap is Empty ");

            return null;
        }
    }



/*
    @Override
    protected void onDestroy() {
        super.onDestroy();
        System.out.println("onDestroy()");
        if(bundle!=null) {
            bundle.clear();
            // i also use the below statement
            // bundle.remove("KEY");
        }
    }
*/

    @Override
    protected void onDestroy() {
        finish();
        b = null;
//        getIntent().removeExtra("image");
        Log.i(TAG,"Data Removed ");
        super.onDestroy();
        Runtime.getRuntime().gc();
        System.gc();
    }


    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }



}
