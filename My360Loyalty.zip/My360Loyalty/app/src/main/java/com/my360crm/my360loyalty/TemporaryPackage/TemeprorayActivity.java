package com.my360crm.my360loyalty.TemporaryPackage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.StartEmployeecamera;
import com.my360crm.my360loyalty.CameraPackage.ExecutiveCamera;
import com.my360crm.my360loyalty.CameraPackage.ImagePreview;
import com.my360crm.my360loyalty.CameraPackage.RegisterActivation;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360loyalty.MainActivity;
import com.my360crm.my360loyalty.R;
import com.my360crm.my360loyalty.SessionManagementPackage.SessionManagement;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class TemeprorayActivity extends androidx.appcompat.app.AppCompatActivity implements Animation.AnimationListener
{
    private static final String TAG = TemeprorayActivity.class.getSimpleName();
    Button registerbutton,cancel;
    EditText registercode;
    ImageView profilepic;
    Bundle bundle;
    private TextView err_msg,user_profilename;
    ImageView anim;
    Animation animFadeOut;
    Bitmap b;
    String passcode;
    private Bitmap editedBitmap;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temeproray);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Log.i(TAG,TAG);
        registerbutton = findViewById(R.id.register);
        cancel = findViewById(R.id.cancel);
        registercode = findViewById(R.id.pinviews);
        profilepic = findViewById(R.id.user_profile_photo);
        err_msg = findViewById(R.id.erro_msg);
        anim = findViewById(R.id.animationimage);
        user_profilename = findViewById(R.id.user_profile_names);
        user_profilename.setText("");
        bundle = getIntent().getExtras();
        assert bundle != null;
        if(getIntent().hasExtra("image")) {
            b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"),0,getIntent()
                            .getByteArrayExtra("image").length);
            profilepic.setImageBitmap(getCircularBitmap(b));

        }

/*
        String status        = bundle.getString("status");
        String userstatus    = bundle.getString("userstatus");
        final String faceid  = bundle.getString("faceid");
        String faceurl       = bundle.getString("faceurl");
        Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "userstatus " + userstatus + "\n" + "faceid " + faceid + "\n" + "faceurl " + faceurl + "\n" + "===========================\n");
*/

        animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.animation);
        registerbutton.setVisibility(View.INVISIBLE);
        cancel.setVisibility(View.INVISIBLE);
        registercode.setVisibility(View.INVISIBLE);
        err_msg.setVisibility(View.INVISIBLE);
        NowUploadtoServer(b);
        passcode = registercode.getText().toString();


         preferences = getApplicationContext().getSharedPreferences("ExecutiveData", MODE_PRIVATE);
         editor = preferences.edit();

/*
        if(passcode.length()==6)
        {
            registercode.setError("Please Enter 6 digit number");
        }

*/

        registerbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Validateuserwithpasscode(passcode,b);

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             startActivity(new Intent(TemeprorayActivity.this,MainActivity.class));
                finish();

            }
        });



    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }

    private void Validateuserwithpasscode(final String passcode, final Bitmap b) {

        circularprogresssdialog.showDialog(TemeprorayActivity.this,"","");
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/AWS.php", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                circularprogresssdialog.dismissdialog();
                try {
                    JSONObject obj = new JSONObject(new String(response.data));
                    Log.i(TAG, obj.toString());
                    String Status = obj.getString("status");
                    if (Status.equals("success")) {
                        String Name = obj.getString("name");
                        String Type = obj.getString("type");
                        startActivity(new Intent(TemeprorayActivity.this, StartEmployeecamera.class));
                        finish();
                    } else if(Status.equals("error") )
                    {
                        String Result = obj.getString("result");
                        if(Result.equals("false") || Result.equals("please recognize your image") || Result.equals("Already registered"));
                        {
                           circularprogresssdialog.showDialog(TemeprorayActivity.this,"","");
                           new Handler().postDelayed(new Runnable() {
                               @Override
                               public void run() {

                                   Snackbar.make(findViewById(android.R.id.content),"Wrong Passcode",Snackbar.LENGTH_LONG).show();
                                   startActivity(new Intent(TemeprorayActivity.this,MainActivity.class));
                                   finish();
                               }
                           },2000);
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override //Something Went Wrong We are Working...
            public void onErrorResponse(VolleyError error) {
                circularprogresssdialog.dismissdialog();
                Snackbar.make(findViewById(android.R.id.content),"!We are Upgrading server to Next Level!", Snackbar.LENGTH_LONG).show();
                Log.e(TAG,"Something error "+error.getMessage());
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                        startActivity(new Intent(TemeprorayActivity.this,MainActivity.class));
                        finish();
                    }
                },3000);

            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                //params.put("tags", tags);
                return params;
            }


            /*
             * Here we are passing image by renaming it with a unique name
             *
             */

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put(""+passcode+"", new DataPart(imagename + ".jpeg", getFileDataFromDrawable(b)));
                return params;
            }

        };multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,DefaultRetryPolicy.DEFAULT_MAX_RETRIES ,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(multipartRequest);
    }

    private void NowUploadtoServer(final Bitmap b) {

        circularprogresssdialog.showDialog(TemeprorayActivity.this,"","");
        MultipartRequest multipartRequest = new MultipartRequest(Request.Method.POST, "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/AWS.php", new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                circularprogresssdialog.dismissdialog();
                try {
                    JSONObject obj = new JSONObject(new String(response.data));
                    Log.i(TAG,obj.toString());
                    Log.i(TAG,"******************************");
                    Log.i(TAG,obj.toString());
                    Log.i(TAG,"******************************");

                    final String Status = obj.getString("status");
                   // String Result = obj.getString("result");
                   // Snackbar.make(findViewById(android.R.id.content),Result,Snackbar.LENGTH_LONG).show();

                    if(Status.equals("error")  )
                    {
                        String Result = obj.getString("result");

                        if(Result.equals("please recognize your image"))
                        {
                            Snackbar.make(findViewById(android.R.id.content),Result + "\nPlease Contact Executive ",Snackbar.LENGTH_LONG).show();

                        } else if(Result.equals("false"))
                        {
                            err_msg.setVisibility(View.VISIBLE);
                            err_msg.setText(R.string.sorry_enter_your_my360access_passcode_to_confirm_your_identity);
                            anim.setVisibility(View.VISIBLE);
                            anim.setImageResource(R.drawable.rite);
                            anim.startAnimation(animFadeOut);
                            registercode.setVisibility(View.VISIBLE);
                            registerbutton.setVisibility(View.VISIBLE);
                            cancel.setVisibility(View.VISIBLE);

                        } else if(Result.equals("inactive user"))
                        {
                            Snackbar.make(findViewById(android.R.id.content),Result + "\nPlease Contact Our Admin ",Snackbar.LENGTH_LONG).show();

                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run()
                                {

                                    startActivity(new Intent(TemeprorayActivity.this,MainActivity.class));

                                }
                            },2000);

                        }
                    }else if(Status.equals("success") )
                    {
                        final String Name = obj.getString("name");
                        final String Type = obj.getString("type");
                        final String Url = obj.getString("url");
                        Log.i(TAG,Status);
                        Log.i(TAG,Name);
                        Log.i(TAG,Type);
                        Log.i(TAG,Url);
                        editor.putString("status",Status);
                        editor.putString("name",Name);
                        editor.putString("type",Type);
                        editor.putString("url",Url);
                        editor.putString("partnerid","PartnerAb1");
                        editor.commit();

                        if(Type.equals("Administrator") || Type.equals("User"))
                        {
                            anim.setVisibility(View.VISIBLE);
                            anim.setImageResource(R.drawable.rite);
                            anim.startAnimation(animFadeOut);
                            user_profilename.setText("Hello "+Name);
                            err_msg.setVisibility(View.VISIBLE);
                            err_msg.setText("My360Loyalty Executive");
                            err_msg.setVisibility(View.VISIBLE);
                            registercode.setVisibility(View.INVISIBLE);
                            registerbutton.setVisibility(View.INVISIBLE);
                            cancel.setVisibility(View.INVISIBLE);
                            Log.i(TAG,"Access Granted");
                            Snackbar.make(findViewById(android.R.id.content),"Hi Executive " +Name+ " Welcome!",Snackbar.LENGTH_LONG).show();




                        circularprogresssdialog.showDialog(TemeprorayActivity.this,"","");
                             new Handler().postDelayed(new Runnable() {
                                 @Override
                                 public void run() {
                                     circularprogresssdialog.dismissdialog();
                                     Intent intent = new Intent(TemeprorayActivity.this,StartEmployeecamera.class);
                                     startActivity(intent);
                                     finish();
                                 }
                             },2000);

                        } else if(Type.equals("Already registered"))
                        {
                            Snackbar.make(findViewById(android.R.id.content),"Hi please Contact Admin!"+Type,Snackbar.LENGTH_LONG).show();
                        }
                        else if(Type.equals("deleted user"))
                        {
                            Snackbar.make(findViewById(android.R.id.content),"Hi please Contact Admin!"+Type,Snackbar.LENGTH_LONG).show();

                        } else if(Type.equals("") && Name.equals(""))
                        {
                            Snackbar.make(findViewById(android.R.id.content),"User Details Not Updated\nplease contact Executive",Snackbar.LENGTH_LONG ).show();
                            Intent newIntent = new Intent(TemeprorayActivity.this,MainActivity.class);
                            newIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            newIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(newIntent);
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();

                    Snackbar.make(findViewById(android.R.id.content),"Please Try again! ",Snackbar.LENGTH_LONG).show();
                    circularprogresssdialog.showDialog(TemeprorayActivity.this,"","");
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            startActivity(new Intent(TemeprorayActivity.this, MainActivity.class));
                            finish();

                        }
                    },1000);


                }

            }
        }, new Response.ErrorListener() {
            @Override //Something Went Wrong We are Working...
            public void onErrorResponse(VolleyError error) {
                circularprogresssdialog.dismissdialog();
                Snackbar.make(findViewById(android.R.id.content),"Bad Internet Connection! Try again ", Snackbar.LENGTH_LONG).show();
                Log.e(TAG,"Something error "+error.getMessage());

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run()
                    {
                       startActivity(new Intent(TemeprorayActivity.this,MainActivity.class));
                       finish();
                    }
                },4000);
            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError
            {
                Map<String, String> params = new HashMap<>();
                //params.put("tags", tags);
                return params;
            }


            /*
             * Here we are passing image by renaming it with a unique name
             *
             */

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                long imagename = System.currentTimeMillis();
                params.put("image", new DataPart(imagename + ".jpeg", getFileDataFromDrawable(b)));
                return params;
            }

        };multipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,DefaultRetryPolicy.DEFAULT_MAX_RETRIES ,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(multipartRequest);


    }

    private void UploadtoNextScreen(String name, String type) {


        Intent in1 = new Intent(TemeprorayActivity.this, StartEmployeecamera.class);
        in1.putExtra("Name",name);
        in1.putExtra("type",type);
        startActivity(in1);
        finish();

    }

    private byte[] getFileDataFromDrawable(Bitmap bitmap) {
        if(bitmap != null)
        {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, byteArrayOutputStream);
            Log.i(TAG,byteArrayOutputStream.toByteArray().toString());
            return byteArrayOutputStream.toByteArray();

        } else
        {
            Log.i(TAG,"Bitmap is Empty ");

            return null;
        }


    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
