package com.my360crm.my360loyalty.CustomersPackage;

public class Earned_Transactions_Data_model
{
    String imageurl,points,partner,member,transaxtionid,timestamp;

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getPoints() {
        return points;
    }

    public void setPoints(String points) {
        this.points = points;
    }

    public String getPartner() {
        return partner;
    }

    public void setPartner(String partner) {
        this.partner = partner;
    }

    public String getMember() {
        return member;
    }

    public void setMember(String member) {
        this.member = member;
    }

    public String getTransaxtionid() {
        return transaxtionid;
    }

    public void setTransaxtionid(String transaxtionid) {
        this.transaxtionid = transaxtionid;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }





}
