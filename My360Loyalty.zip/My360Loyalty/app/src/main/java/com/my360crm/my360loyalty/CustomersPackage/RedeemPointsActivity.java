package com.my360crm.my360loyalty.CustomersPackage;

import android.content.Intent;
import android.os.Handler;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360loyalty.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class RedeemPointsActivity extends androidx.appcompat.app.AppCompatActivity {



    TextView info,doubt;
    Button redembtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redeem_points);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Bundle bundle = getIntent().getExtras();
        assert bundle != null;
        final String account = bundle.getString("accountnumer");
        final String card = bundle.getString("cardid");
        final String points = bundle.getString("points");

        info = findViewById(R.id.info1);
        doubt = findViewById(R.id.doubt);
        redembtn = findViewById(R.id.redemnow);

        redembtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {

                UploadtoServer(account,card,points,"partnerC");


            }
        });

    }

    private void UploadtoServer(final String account, final String card, final String points, final String partnerC) {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, "", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);

                    boolean success = jsonObject.getBoolean("success");
                    if(success)
                    {
                        redembtn.setVisibility(View.INVISIBLE);
                        info.setText("Thanks For Shopping with Us!");
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run()
                            {
                                startActivity(new Intent(RedeemPointsActivity.this,OldCustomerActivity.class));
                            }
                        },3000);

                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Snackbar.make(findViewById(android.R.id.content),"Server Busy: Please Try again after Sometime! ",Snackbar.LENGTH_LONG).show();

            }
        })
        {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String, String> params = new HashMap<>();

                params.put("accountnumber",account);
                params.put("cardid",card);
                params.put("points",points);
                params.put("partnerid","partnerC");

                return params;
            }
        };stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        Volley.newRequestQueue(this).add(stringRequest);



    };


}

