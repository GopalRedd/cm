package com.my360crm.my360loyalty.ExecutiveProfilePackage;

import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.my360crm.my360loyalty.R;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.Objects;

public class ExecutiveProfile extends androidx.appcompat.app.AppCompatActivity {

    private static final String TAG = ExecutiveProfile.class.getSimpleName() ;
    ImageView profile_pic;
    TextView name,type,partnerid;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_executive_profile);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        profile_pic = findViewById(R.id.executive_profile_photo);
        name = findViewById(R.id.executivename);
        type = findViewById(R.id.executivetype);
        partnerid = findViewById(R.id.partnerid);

        sharedPreferences = getSharedPreferences("ExecutiveData", MODE_PRIVATE);
        String status = sharedPreferences.getString("status",null);
        String namestring = sharedPreferences.getString("name",null);
        final String typestring = sharedPreferences.getString("type",null);
        final String faceurl = sharedPreferences.getString("url",null);
        final String partnerid1 = sharedPreferences.getString("partnerid",null);
        Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "Name " + namestring + "\n" + "Type " + typestring + "\n" + "faceurl " + faceurl + "\n" +"Partner Id " + partnerid1 + "\n" + "===========================\n");

        name.setText(namestring);
        type.setText(R.string.executive);
        partnerid.setText(partnerid1);


        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                Log.d("DEBUG", "onBitmapLoaded");
                //progress_bar.setVisibility(View.GONE);
                profile_pic.setImageBitmap(getCircularBitmap(bitmap));
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                Log.d("DEBUG", "onBitmapFailed");
            }


            @Override
            public void onPrepareLoad(Drawable drawable) {
                Log.d("DEBUG", "onPrepareLoad");
            }
        };
        Picasso.get().load(faceurl).into(mTarget);
        profile_pic.setTag(mTarget);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }



    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    }

