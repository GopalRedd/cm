package com.my360crm.my360loyalty.CustomersPackage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360loyalty.Bottomsheetlistview;
import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.EmployeeCamera;
import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.StartEmployeecamera;
import com.my360crm.my360loyalty.CameraPackage.RegisterActivation;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.InternetPackage.MyApplication;
import com.my360crm.my360loyalty.JsonNetworkPackage.AppController;
import com.my360crm.my360loyalty.JsonNetworkPackage.MultipartRequest;
import com.my360crm.my360loyalty.R;
import com.my360crm.my360loyalty.TemporaryPackage.TemeprorayActivity;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class OldCustomerActivity extends AppCompatActivity  {

    private static final String TAG = OldCustomerActivity.class.getSimpleName();
    TextView name, email, phonenumber, accountnumber,cardid, points, redemepoints, newuser, cancel;
    ImageView personimage;
    Bundle bundle;
    TextView earnpoints, usedpoints,transactions,total;
    ListView listView;
    SharedPreferences prefs;
    com.getbase.floatingactionbutton.FloatingActionButton fab1;
    com.getbase.floatingactionbutton.FloatingActionButton fab2;
    String status ;
    String userstatus ;
    String faceid ;
    String faceurl ;
    String[] values;
    String itemurl;
    String[] items = {"Select Item", "bag", "watch", "belt", "shoe", };
    String accountNumber ;
    String cardId ;
    SharedPreferences.Editor editor;
    Button alltransactions;
    ArrayList<Transaction_Data_Model> dataModelArrayList;
    private Transactions_List_Adapter listAdapter;

    ArrayList<Earned_Transactions_Data_model> earned_transactions_data_models;
    private  Earned_Transactions_List_Adapter earnedlistadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_old_customer);
/*        Objects.requireNonNull(getSupportActionBar()).hide();*/

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        bundle = getIntent().getExtras();
        assert bundle != null;
         status = bundle.getString("status");
         userstatus = bundle.getString("userstatus");
         faceid = bundle.getString("faceid");
         faceurl = bundle.getString("faceurl");
        Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "userstatus " + userstatus + "\n" + "faceid " + faceid + "\n" + "faceurl " + faceurl + "\n" + "===========================\n");

        GoandGetDetailsofOldCustomer(faceid);

        Log.i(TAG, faceid);
        name = findViewById(R.id.user_profile_name);
        email = findViewById(R.id.email);
        earnpoints = findViewById(R.id.earn_point);
        usedpoints = findViewById(R.id.used_points);
        phonenumber = findViewById(R.id.phone);
        transactions = findViewById(R.id.transactions);
        listView = findViewById(R.id.listview);
        total = findViewById(R.id.total);
        alltransactions = findViewById(R.id.all_transactions);

        //accountnumber = findViewById(R.id.accountnum);
        points = findViewById(R.id.points);
        personimage = findViewById(R.id.user_profile_photo);

        usedpoints.setText("0");
        earnpoints.setText("0");
        fab1 =  findViewById(R.id.fab1);
        fab2  = findViewById(R.id.fab2);

        editor = getSharedPreferences("MemeberData",MODE_PRIVATE).edit();
        prefs = getSharedPreferences("MemeberData", MODE_PRIVATE);
        accountNumber = prefs.getString("accountnumber",null);
        cardId = prefs.getString("cardid",null);


               // GetMemebersData(accountNumber,cardId);

    listView.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {


            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                int lastItem = firstVisibleItem + visibleItemCount;


                Log.i(TAG, "first "+String.valueOf(firstVisibleItem));
                Log.i(TAG, "visible "+String.valueOf(visibleItemCount));
                Log.i(TAG, "3rd "+String.valueOf(totalItemCount));

                // add here your logic like this
/*              if (firstVisibleItem < 1) {

                   alltransactions.setVisibility(View.INVISIBLE);

                }else {*/


                    if(visibleItemCount >= 3) {

                                alltransactions.setVisibility(View.VISIBLE);
                    }  }
        });

        alltransactions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(OldCustomerActivity.this,AllTransactions.class);
                startActivity(intent);

            }
        });


        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final AlertDialog dialogBuilder = new AlertDialog.Builder(OldCustomerActivity.this).create();
                LayoutInflater inflater = OldCustomerActivity.this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.custom_edittext, null);
                final EditText addpoints = (EditText) dialogView.findViewById(R.id.addpoints);
                final Spinner additem = (Spinner) dialogView.findViewById(R.id.itemsurl);
                ArrayAdapter aa = new ArrayAdapter(OldCustomerActivity.this,android.R.layout.simple_spinner_item,items);
                aa.setDropDownViewResource(android.R.layout.simple_list_item_1);
                //Setting the ArrayAdapter data on the Spinner

                additem.setAdapter(aa);
                additem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                        if(i == 0)
                        {
                        Snackbar.make(findViewById(android.R.id.content),"Please Select item ",Snackbar.LENGTH_LONG).show();
                        }else if(i == 1)
                        {

                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/bag.jpg";

                        }else if(i ==2)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/watch.jpg";


                        }else if(i == 3)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/belt.jpg";

                        }if(i == 4)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/shoe.jpg";

                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                Button button1 = (Button) dialogView.findViewById(R.id.addpo);
                Button button2 = (Button) dialogView.findViewById(R.id.canceladding);

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogBuilder.dismiss();
                    }
                });
                button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // DO SOMETHINGS
                        String npoints = "0";
                        npoints = String.valueOf(addpoints.getText());
                        String oldpoints = String.valueOf(earnpoints.getText());
                        //int res = Integer.parseInt(oldpoints) + Integer.parseInt(npoints);
                        //earnpoints.setText(Integer.toString(res));
                        dialogBuilder.dismiss();

                        EarnedPoints(npoints,itemurl);
                        Log.i(TAG,npoints + "item url" +itemurl);


                    }
                });

                dialogBuilder.setView(dialogView);
                dialogBuilder.show();
            }
        });




        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog dialogBuilder = new AlertDialog.Builder(OldCustomerActivity.this).create();
                LayoutInflater inflater = OldCustomerActivity.this.getLayoutInflater();
                View dialogView = inflater.inflate(R.layout.custom_edittext_red, null);

                final EditText usepoints = (EditText) dialogView.findViewById(R.id.usepoints);
                final Spinner additem = (Spinner) dialogView.findViewById(R.id.itemsurl);

                ArrayAdapter aa = new ArrayAdapter(OldCustomerActivity.this,android.R.layout.simple_spinner_item,items);
                aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                //Setting the ArrayAdapter data on the Spinner
                additem.setAdapter(aa);
                additem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                        if(i == 0)
                        {
                            Snackbar.make(findViewById(android.R.id.content),"Please Select item",Snackbar.LENGTH_LONG).show();
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/bag.jpg";

                        }else if(i == 1)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/bag.jpg";

                        }else if(i ==2)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/watch.jpg";


                        }else if(i == 3)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/belt.jpg";

                        }if(i == 4)
                        {
                            itemurl = "https://internal.my360crm.com/website/190507150303DEMOCRM/include/Webservices/prod_images/shoe.jpg";

                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });



                Button button1 = (Button) dialogView.findViewById(R.id.usepo);
                Button button2 = (Button) dialogView.findViewById(R.id.cancelred);

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogBuilder.dismiss();
                    }
                });
                button1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // DO SOMETHINGS
                        String npoints ="0";
                        npoints = String.valueOf(usepoints.getText());
                        String oldpoints = String.valueOf(earnpoints.getText());
                       // int res = Integer.parseInt(oldpoints) - Integer.parseInt(npoints);
                        //usedpoints.setText(Integer.toString(res));
                       // usedpoints.setText(npoints);
                        dialogBuilder.dismiss();
                        UsedPoints(npoints,itemurl);
                        //updateusedpointsinserver(npoints,itemurl);
                        Log.i(TAG,npoints+itemurl);
                       /* GetMemebersData(accountNumber,cardId);
                        Log.i(TAG,accountNumber+"card  " +cardId);
*/
                    }
                });

                dialogBuilder.setView(dialogView);
                dialogBuilder.show();
            }
        });

        final Target mTarget = new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom loadedFrom) {
                Log.d("DEBUG", "onBitmapLoaded");
                //progress_bar.setVisibility(View.GONE);
                personimage.setImageBitmap(getCircularBitmap(bitmap));
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                Log.d("DEBUG", "onBitmapFailed");

            }


            @Override
            public void onPrepareLoad(Drawable drawable) {
                Log.d("DEBUG", "onPrepareLoad");
            }
        };
        Picasso.get().load(faceurl).into(mTarget);
        personimage.setTag(mTarget);


    }

    private void UsedPoints(final String npoints, final String itemurl) {

        final String accountnumber = prefs.getString("accountnumber",null);
        final String cardid = prefs.getString("cardid",null);
        final String partner = prefs.getString("partnerid","ABC");
        circularprogresssdialog.showDialog(OldCustomerActivity.this,"","");
        final StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:8000/api/usePoints", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Use Points Success Response "+ response);
                /*                Snackbar.make(findViewById(android.R.id.content),response,Snackbar.LENGTH_LONG).show();*/
                usedpoints.setText(npoints);
                GetMemebersData(accountNumber,cardId);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Use Points Error Response "+ error);
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again",Snackbar.LENGTH_LONG).show();

            }
        })

        {
            @Override
            public byte[] getBody()  {

                String json = "{\"accountnumber\":\""+accountnumber+"\",\"cardid\":\""+cardid+"\",\"points\":\""+npoints+"\",\"partnerid\":\""+partner+"\",\"productId\":\""+itemurl+"\" }";
                Log.i("Gopal " + TAG, json);
                return json.getBytes();
            }
            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 40000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        MyApplication.getInstance().addToRequestQueue(stringRequest);


    }

    private void EarnedPoints(final String npoints, final String itemurl)
    {


        final String accountnumber = prefs.getString("accountnumber",null);
        final String cardid = prefs.getString("cardid",null);
        final String partner = prefs.getString("partnerid","ABC");

        circularprogresssdialog.showDialog(OldCustomerActivity.this,"","");
        final StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:8000/api/earnPoints", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Earn Points Success Response "+ response);
/*                Snackbar.make(findViewById(android.R.id.content),response,Snackbar.LENGTH_LONG).show();*/
                earnpoints.setText(npoints);

                GetMemebersData(accountNumber,cardId);


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Earn Points Error Response "+ error);
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again",Snackbar.LENGTH_LONG).show();

            }
        })

        {
            @Override
            public byte[] getBody()  {

                String json = "{\"accountnumber\":\""+accountnumber+"\",\"cardid\":\""+cardid+"\",\"points\":\""+npoints+"\",\"partnerid\":\""+partner+"\",\"productId\":\""+itemurl+"\" }";
                Log.i("Gopal " + TAG, json);
                return json.getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };stringRequest.setRetryPolicy(new RetryPolicy() {
                                           @Override
                                           public int getCurrentTimeout() {
                                               return 40000;
                                           }

                                           @Override
                                           public int getCurrentRetryCount() {
                                               return 50000;
                                           }

                                           @Override
                                           public void retry(VolleyError error) throws VolleyError {

                                           }
                                       });
        MyApplication.getInstance().addToRequestQueue(stringRequest);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cancel_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.cancel) {
            circularprogresssdialog.showDialog(OldCustomerActivity.this, "", "");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    circularprogresssdialog.dismissdialog();
                    startActivity(new Intent(OldCustomerActivity.this, StartEmployeecamera.class));
                    finish();
                }
            }, 2000);


            return true;
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }


    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;
        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);
        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);
        return output;
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(OldCustomerActivity.this, EmployeeCamera.class));
        finish();
    }



    /******Old Customer Details ********/


    private void GoandGetDetailsofOldCustomer(final String faceid) {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:5984/composerchannel_clp-network/_find", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, response);
                //Snackbar.make(findViewById(android.R.id.content), response, Snackbar.LENGTH_LONG).show();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String docs = jsonObject.getString("docs");
                    String bookmark = jsonObject.getString("bookmark");
                    String warning = jsonObject.getString("warning");
                    Log.i(TAG, "Docs " + docs);
                    Log.i(TAG, "BookMark " + bookmark);
                    Log.i(TAG, "Warning " + warning);

                    if (bookmark.equals("nil")) {
                        Intent intent = new Intent(OldCustomerActivity.this, NewCustomerActivity.class);
                        intent.putExtra("status", status);
                        intent.putExtra("userstatus", userstatus);
                        intent.putExtra("faceid", faceid);
                        intent.putExtra("faceurl", faceurl);
                        startActivity(intent);

                    } else if (!bookmark.equals("nil")) {
                        JSONArray jsonArray = jsonObject.optJSONArray("docs");
                        String firstName = null;
                        accountNumber = null;
                        cardId = null;
                        String email1 = null;
                        String faceId = null;
                        String lastName = null;
                        String phoneNumber = null;
                        String pointss = null;
                        String userType = null;
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            String id = jsonObject1.optString("_id").toString();
                            Log.i(TAG, id);
                            String _rev = jsonObject1.optString("_rev").toString();
                            String $class = jsonObject1.optString("$class").toString();
                            String $registryId = jsonObject1.optString("$registryId").toString();
                            String $registryType = jsonObject1.optString("$registryType").toString();
                            accountNumber = jsonObject1.optString("accountNumber").toString();
                            Log.i(TAG, accountNumber);
                            cardId = jsonObject1.optString("cardId").toString();
                            Log.i(TAG, cardId);
                            email1 = jsonObject1.optString("email").toString();
                            Log.i(TAG, email1);
                            email.setText("Email id: " + email1);
                            faceId = jsonObject1.optString("faceId").toString();
                            Log.i(TAG, faceId);
                            firstName = jsonObject1.optString("firstName").toString();
                            Log.i(TAG, firstName);
                            lastName = jsonObject1.optString("lastName").toString();
                            Log.i(TAG, lastName);
                            name.setText("Name: " + firstName + " " + lastName);
                            phoneNumber = jsonObject1.optString("phoneNumber").toString();
                            Log.i(TAG, phoneNumber);
                            phonenumber.setText("Contact Number: " + phoneNumber);
                            pointss = jsonObject1.optString("points").toString();
                            total.setText(pointss);
                            Log.i(TAG, pointss);
                            userType = jsonObject1.optString("userType").toString();
                            //String version = jsonObject1.optString("~version").toString();
                            Log.i(TAG, userType);
                            editor.clear();
                            editor.putString("accountnumber", accountNumber);
                            editor.putString("cardid", cardId);
                            editor.commit();
                            Log.i(TAG, "Prefers " + prefs.getString("accountnumber", null));
                            Log.i(TAG, "Prefers " + prefs.getString("cardid", null));

                            GetMemebersData(accountNumber,cardId);

                        }

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.i(TAG, error.toString());
                Snackbar.make(findViewById(android.R.id.content), " Bad internet! Unable to Featch details ", Snackbar.LENGTH_LONG).show();

            }
        }) {

            @Override
            public byte[] getBody() throws com.android.volley.AuthFailureError {

                String json = "{\"selector\":{\"faceId\":\"" + faceid + "\"}}";
                Log.i("Gopal " + TAG, json);
                return json.getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }


        };stringRequest.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 40000;
            }

            @Override
            public int getCurrentRetryCount() {
                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });
        MyApplication.getInstance().addToRequestQueue(stringRequest);
    }


        /******Memebers Data ********/


    private void GetMemebersData(final String accountNumber, final String cardId)
    {
        circularprogresssdialog.showDialog(OldCustomerActivity.this,"","");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:8000/api/memberData", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Get Members data response"+response);
       //         Snackbar.make(findViewById(android.R.id.content),response,Snackbar.LENGTH_LONG).show();

                try {

                    dataModelArrayList = new ArrayList<Transaction_Data_Model>();
                    earned_transactions_data_models = new ArrayList<Earned_Transactions_Data_model>();


                    JSONObject  jsonObject = new JSONObject(response);
                    String acuntnum = jsonObject.getString("accountNumber");
                    String fir = jsonObject.getString("firstName");
                    String last = jsonObject.getString("lastName");
                    String phn = jsonObject.getString("phoneNumber");
                    String ema = jsonObject.getString("email");
                    String tpoints = jsonObject.getString("points");
                    total.setText(tpoints);
                    String cardId = jsonObject.getString("cardId");
                    String feId = jsonObject.getString("faceId");
                    String fceURL = jsonObject.getString("faceURL");
                    String usrStatus = jsonObject.getString("userStatus");

                    JSONArray jsonArray = jsonObject.getJSONArray("usePointsResults");
                    JSONArray jsonArray1 = jsonObject.getJSONArray("earnPointsResult");


                    if(jsonArray!= null) {

                        for (int i = 0; i < jsonArray.length(); i++) {

                            Transaction_Data_Model transactiondetails = new Transaction_Data_Model();
                            JSONObject jsonobject = jsonArray.getJSONObject(i);
                            String classs = jsonobject.getString("$class");
                            String upoints = jsonobject.getString("points");
                            Log.i(TAG, "Redemed "+upoints);
                            usedpoints.setText(upoints);
                            String producturl = jsonobject.getString("productId");
                            String partne = jsonobject.getString("partner");
                            String membe = jsonobject.getString("member");
                            String transaction = jsonobject.getString("transactionId");
                            String timestam = jsonobject.getString("timestamp");

                            transactiondetails.setImageurl(producturl);
                            transactiondetails.setPoints("Redeemed " + upoints);
                            transactiondetails.setPartner(partne);
                            transactiondetails.setMember(membe);
                            transactiondetails.setTransaxtionid(transaction);
                            transactiondetails.setTimestamp(timestam);
                            dataModelArrayList.add(transactiondetails);
/*                        synchronized(dataModelArrayList){
                            dataModelArrayList.notify();
                        }*/
                            setUplistview();

                        }

                    } else
                    {
                        Snackbar.make(findViewById(android.R.id.content),"No History found",Snackbar.LENGTH_LONG).show();
                    }

                if(jsonArray1 != null)
                {

                    for (int i = 0; i < jsonArray1.length(); i++)
                    {
                        Earned_Transactions_Data_model earned_transactions_details = new Earned_Transactions_Data_model();

                        Transaction_Data_Model transactiondetails = new Transaction_Data_Model();

                        JSONObject jsonobject = jsonArray1.getJSONObject(i);
                        String classs = jsonobject.getString("$class");
                        String epoints = jsonobject.getString("points");
                        earnpoints.setText(epoints);
                        Log.i(TAG,"Earned "+epoints);
                        String producturl = jsonobject.getString("productId");
                        String partne = jsonobject.getString("partner");
                        String membe = jsonobject.getString("member");
                        String transaction = jsonobject.getString("transactionId");
                        Log.i(TAG,transaction);
                        String timestam = jsonobject.getString("timestamp");
                        transactiondetails.setImageurl(producturl);
                        transactiondetails.setPoints("Earned " + epoints);
                        transactiondetails.setPartner(partne);
                        transactiondetails.setMember(membe);
                        transactiondetails.setTransaxtionid(transaction);
                        transactiondetails.setTimestamp(timestam);

                        dataModelArrayList.add(transactiondetails);
/*                        synchronized(dataModelArrayList){
                            dataModelArrayList.notify();
                        }*/
                        setUplistview();


                    } } else
                {
                    Snackbar.make(findViewById(android.R.id.content),"No History Found ",Snackbar.LENGTH_LONG).show();
                }



                    JSONArray jsonArray2 = jsonObject.optJSONArray("partnersData");
                    for (int i = 0; i < jsonArray2.length(); i++) {
                        JSONObject jsonobject = jsonArray2.getJSONObject(i);
                        String classs = jsonobject.getString("$class");
                        String id = jsonobject.getString("id");
                        editor.putString("partnerid",id);
                        Log.i(TAG,id);
                        String name = jsonobject.getString("name");
                        String faceId = jsonobject.getString("faceId");
                        String faceURL = jsonobject.getString("faceURL");
                        String cardd = jsonobject.getString("cardId");
                        String userType = jsonobject.getString("userType");
                        String executiveName = jsonobject.getString("executiveName");
                        Log.i(TAG,"Executive "+executiveName);
                    }

                }

                catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG," members error "+error.toString());
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again",Snackbar.LENGTH_LONG).show();

            }
        }) {

            @Override
            public byte[] getBody() throws com.android.volley.AuthFailureError {

                String json1 = "{\"accountnumber\":\""+accountNumber+"\",\"cardid\":\""+cardId+"\"}";;
                Log.i("Gopal " + TAG, json1);
                return json1.getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };stringRequest.setRetryPolicy(new RetryPolicy() {
        @Override
        public int getCurrentTimeout() {
            return 40000;
        }

        @Override
        public int getCurrentRetryCount() {
            return 50000;
        }

        @Override
        public void retry(VolleyError error) throws VolleyError {

        }
    });
        MyApplication.getInstance().addToRequestQueue(stringRequest);

    }

    private void earnedsetUplistview() {

        earnedlistadapter = new Earned_Transactions_List_Adapter(this,earned_transactions_data_models);
        listView.setAdapter(listAdapter);

    }

    private void setUplistview() {
        listAdapter = new Transactions_List_Adapter(this, dataModelArrayList);
        listView.setAdapter(listAdapter);
    }



}
