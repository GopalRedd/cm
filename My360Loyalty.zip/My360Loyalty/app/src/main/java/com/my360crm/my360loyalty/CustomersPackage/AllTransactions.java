package com.my360crm.my360loyalty.CustomersPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.snackbar.Snackbar;
import com.my360crm.my360loyalty.CircularProgressbarPackage.circularprogresssdialog;
import com.my360crm.my360loyalty.InternetPackage.MyApplication;
import com.my360crm.my360loyalty.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Objects;

public class AllTransactions extends AppCompatActivity {

    private static final  String TAG = AllTransactions.class.getSimpleName();
    SharedPreferences prefs;
    String accountNumber;
    String cardId;
    ArrayList<Transaction_Data_Model> dataModelArrayList;
    private Transactions_List_Adapter listAdapter;
    ListView listview_trans;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_transactions);
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        prefs = getSharedPreferences("MemeberData", MODE_PRIVATE);
        accountNumber = prefs.getString("accountnumber",null);
        cardId = prefs.getString("cardid",null);
        listview_trans = findViewById(R.id.all_trans_listview);


        GetMemebersData(accountNumber,cardId);


    }


    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void GetMemebersData(final String accountNumber, final String cardId)
    {
        circularprogresssdialog.showDialog(AllTransactions.this,"","");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "http://13.238.201.184:8000/api/memberData", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG,"Get Members data response"+response);
                //         Snackbar.make(findViewById(android.R.id.content),response,Snackbar.LENGTH_LONG).show();

                try {

                    dataModelArrayList = new ArrayList<Transaction_Data_Model>();

                    JSONObject jsonObject = new JSONObject(response);
                    String acuntnum = jsonObject.getString("accountNumber");
                    String fir = jsonObject.getString("firstName");
                    String last = jsonObject.getString("lastName");
                    String phn = jsonObject.getString("phoneNumber");
                    String ema = jsonObject.getString("email");
                    String tpoints = jsonObject.getString("points");
                    String cardId = jsonObject.getString("cardId");
                    String feId = jsonObject.getString("faceId");
                    String fceURL = jsonObject.getString("faceURL");
                    String usrStatus = jsonObject.getString("userStatus");
                    JSONArray jsonArray = jsonObject.optJSONArray("usePointsResults");
                    for (int i = 0; i < jsonArray.length(); i++) {

                        Transaction_Data_Model transactiondetails = new Transaction_Data_Model();

                        JSONObject jsonobject = jsonArray.getJSONObject(i);
                        String classs = jsonobject.getString("$class");
                        String upoints = jsonobject.getString("points");
                        Log.i(TAG,upoints);
                        String producturl = jsonobject.getString("productId");
                        String partne = jsonobject.getString("partner");
                        String membe = jsonobject.getString("member");
                        String transaction = jsonobject.getString("transactionId");
                        String timestam = jsonobject.getString("timestamp");

                        transactiondetails.setImageurl(producturl);
                        transactiondetails.setPoints("Redeemed "+upoints);
                        transactiondetails.setPartner(partne);
                        transactiondetails.setMember(membe);
                        transactiondetails.setTransaxtionid(transaction);
                        transactiondetails.setTimestamp(timestam);

                        dataModelArrayList.add(transactiondetails);
/*                        synchronized(dataModelArrayList){
                            dataModelArrayList.notify();
                        }*/
                    }
                    setUplistview();

                    JSONArray jsonArray1 = jsonObject.optJSONArray("earnPointsResult");
                    for (int i = 0; i < jsonArray.length(); i++) {

                        Transaction_Data_Model transactiondetails = new Transaction_Data_Model();
                        JSONObject jsonobject = jsonArray1.getJSONObject(i);
                        String classs = jsonobject.getString("$class");
                        String upoints = jsonobject.getString("points");
                        Log.i(TAG,upoints);
                        String producturl = jsonobject.getString("productId");
                        String partne = jsonobject.getString("partner");
                        String membe = jsonobject.getString("member");
                        String transaction = jsonobject.getString("transactionId");
                        Log.i(TAG,transaction);
                        String timestam = jsonobject.getString("timestamp");

                        transactiondetails.setImageurl(producturl);
                        transactiondetails.setPoints("Earned "+upoints);
                        transactiondetails.setPartner(partne);
                        transactiondetails.setMember(membe);
                        transactiondetails.setTransaxtionid(transaction);
                        transactiondetails.setTimestamp(timestam);

                        dataModelArrayList.add(transactiondetails);
  /*                      synchronized(dataModelArrayList){
                            dataModelArrayList.notify();
                        }
*/



                    }

                    setUplistview();


                    JSONArray jsonArray2 = jsonObject.optJSONArray("partnersData");
                    for (int i = 0; i < jsonArray2.length(); i++) {
                        JSONObject jsonobject = jsonArray2.getJSONObject(i);
                        String classs = jsonobject.getString("$class");
                        String id = jsonobject.getString("id");
                        Log.i(TAG,id);
                        String name = jsonobject.getString("name");
                        String faceId = jsonobject.getString("faceId");
                        String faceURL = jsonobject.getString("faceURL");
                        String cardd = jsonobject.getString("cardId");
                        String userType = jsonobject.getString("userType");
                        String executiveName = jsonobject.getString("executiveName");
                        Log.i(TAG,"Executive "+executiveName);
                    }

                }

                catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                circularprogresssdialog.dismissdialog();
                Log.i(TAG," members error "+error.toString());
                Snackbar.make(findViewById(android.R.id.content)," Bad internet! try again",Snackbar.LENGTH_LONG).show();

            }
        }) {

            @Override
            public byte[] getBody() throws com.android.volley.AuthFailureError {

                String json1 = "{\"accountnumber\":\""+accountNumber+"\",\"cardid\":\""+cardId+"\"}";;
                Log.i("Gopal " + TAG, json1);
                return json1.getBytes();
            }

            @Override
            public String getBodyContentType() {
                return "application/json; charset=utf-8";
            }
        };stringRequest.setRetryPolicy(new RetryPolicy() {
        @Override
        public int getCurrentTimeout() {
            return 40000;
        }

        @Override
        public int getCurrentRetryCount() {
            return 50000;
        }

        @Override
        public void retry(VolleyError error) throws VolleyError {

        }
    });
        MyApplication.getInstance().addToRequestQueue(stringRequest);

    }

    private void setUplistview() {
        listAdapter = new Transactions_List_Adapter(this, dataModelArrayList);
        listview_trans.setAdapter(listAdapter);

    }

}
