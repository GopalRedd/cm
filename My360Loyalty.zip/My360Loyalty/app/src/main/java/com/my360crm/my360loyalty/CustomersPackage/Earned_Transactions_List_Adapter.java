package com.my360crm.my360loyalty.CustomersPackage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.my360crm.my360loyalty.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Earned_Transactions_List_Adapter  extends BaseAdapter
{



    private Context context;
    private ArrayList<Earned_Transactions_Data_model> earneddataModelArrayList;


    public Earned_Transactions_List_Adapter(Context context,ArrayList<Earned_Transactions_Data_model> earneddataModelArrayList) {

        this.context = context;
        this.earneddataModelArrayList = earneddataModelArrayList;

    }


    @Override
    public int getViewTypeCount() {
        if(getCount() > 0){
            return getCount();
        }else{
            return super.getViewTypeCount();
        }
    }
    @Override
    public int getItemViewType(int position) {

        return position;
    }
    @Override
    public int getCount() {
        return earneddataModelArrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return earneddataModelArrayList.get(position);
    }


    @Override
    public long getItemId(int position) {
        return 0;
    }


    @Override
    public View getView(int position, View convertview, ViewGroup parent) {

        ViewHolder holder;

        if(convertview == null)
        {
            holder = new ViewHolder();
            LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertview = layoutInflater.inflate(R.layout.transaction_layout,null,true);

            holder.imageView = convertview.findViewById(R.id.imageView);
            holder.points = convertview.findViewById(R.id.points);
            holder.partner = convertview.findViewById(R.id.textViewpartner);
            holder.member = convertview.findViewById(R.id.textViewmember);
            holder.transaxationid = convertview.findViewById(R.id.textViewtransaction);
            holder.timestamp = convertview.findViewById(R.id.textViewtime);

            convertview.setTag(holder);



        } else
        {
            holder = (ViewHolder)convertview.getTag();
        }

        if(earneddataModelArrayList.get(position).getImageurl().isEmpty())
        {
            holder.imageView.setImageResource(R.drawable.noimage);
        }else
        {
            Picasso.get().load(earneddataModelArrayList.get(position).getImageurl()).into(holder.imageView);
        }
        holder.points.setText("Points: "+earneddataModelArrayList.get(position).getPoints());
        holder.partner.setText("Partner: "+earneddataModelArrayList.get(position).getPartner());
        holder.member.setText("Member: "+earneddataModelArrayList.get(position).getMember());
        holder.transaxationid.setText("Transaction: "+earneddataModelArrayList.get(position).getTransaxtionid());
        holder.timestamp.setText("Time: "+earneddataModelArrayList.get(position).getTimestamp());
        return convertview;
    }

    private class ViewHolder {

        TextView points,partner,member,transaxationid,timestamp;
        ImageView imageView;

    }}
