package com.my360crm.my360loyalty.CameraPackage;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.EmployeeCamera;
import com.my360crm.my360loyalty.CameraPackage.EmployeePackage.StartEmployeecamera;
import com.my360crm.my360loyalty.R;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class RegisterActivation extends AppCompatActivity implements Animation.AnimationListener{


    private static final String TAG = RegisterActivation.class.getSimpleName();
    TextView cancel,next,main_msg,err_msg,user_profilename;
    ImageView detected_face;
    EditText pinview;
    String pinviewstr;
    ImageView anim;
    Animation animFadeOut;
    String  name;
    String  type;
    private static final int SELECTED_PIC = 1;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_activation);
        Objects.requireNonNull(getSupportActionBar()).hide();
        Log.i(TAG,TAG);
        bundle = getIntent().getExtras();
        assert bundle != null;
        String status = bundle.getString("status");
        String userstatus = bundle.getString("userstatus");
        final String faceid = bundle.getString("faceid");
        String faceurl = bundle.getString("faceurl");
        Log.i(TAG, "\n===========================" + "\nstatus " + status + "\n" + "userstatus " + userstatus + "\n" + "faceid " + faceid + "\n" + "faceurl " + faceurl + "\n" + "===========================\n");

        detected_face = findViewById(R.id.user_profile_photo);
        cancel = findViewById(R.id.cancel);
        pinview = findViewById(R.id.pinview);
        main_msg = findViewById(R.id.main_msg);
        err_msg = findViewById(R.id.err_msg);
        anim = findViewById(R.id.animaimage);
        user_profilename = findViewById(R.id.user_profile_name);
        /*next.setVisibility(View.INVISIBLE);*/
        /*pinview.setVisibility(View.INVISIBLE);*/
        animFadeOut = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.animation);
        /*if(getIntent().hasExtra("image")) {
            Bitmap b = BitmapFactory.decodeByteArray(
                    getIntent().getByteArrayExtra("image"),0,getIntent()
                            .getByteArrayExtra("image").length);
            getCircularBitmap(b);
            detected_face.setImageBitmap(getCircularBitmap(b));
        }*/
        Picasso.get()
                .load(faceurl)
                .placeholder(R.drawable.ic_person_add_black_24dp)   // optional
                .resize(800,800)                        // optional
                .into(detected_face);



        Bundle gt=getIntent().getExtras();
        assert gt != null;
        name =gt.getString("name");
        type =gt.getString("type");


        if(name!=null && type !=null)
        {
            user_profilename.setText("Hello "+name);
            main_msg.setText("My360ACCESS");
            err_msg.setVisibility(View.INVISIBLE);
            pinview.setVisibility(View.INVISIBLE);
            next.setVisibility(View.INVISIBLE);
            anim.setVisibility(View.VISIBLE);
            anim.setImageResource(R.drawable.rite);
            anim.startAnimation(animFadeOut);
            Log.i(TAG,"Access Granted");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                }
            },2000);


        }else
        {

            //user_profilename.setText("Hello Admin"/*name*/);
            main_msg.setText("My360Loyality");
            err_msg.setVisibility(View.INVISIBLE);
            pinview.setVisibility(View.INVISIBLE);
            next.setVisibility(View.INVISIBLE);
            anim.setVisibility(View.VISIBLE);
            anim.setImageResource(R.drawable.rite);
            anim.startAnimation(animFadeOut);
            Log.i(TAG,"Access Granted");
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run()
                {
                    startActivity(new Intent(RegisterActivation.this, StartEmployeecamera.class));
                    finish();
                }
            },2000);

             /*

             user_profilename.setText("Passcode");
             main_msg.setText(R.string.unauthorized_identification);
             err_msg.setText(R.string.sorry_enter_your_my360access_passcode_to_confirm_your_identity);
             pinview.setVisibility(View.VISIBLE);
             Log.i(TAG,"Sorry");
             anim.setVisibility(View.VISIBLE);
             anim.setImageResource(R.drawable.wrong);
             anim.startAnimation(animFadeOut);
*/
        }

        animFadeOut.setAnimationListener(this);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);

            }
        });

        pinviewstr = pinview.getText().toString();

        pinview.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event){
                if((event.getAction()==KeyEvent.ACTION_DOWN)&&
                        (keyCode==KeyEvent.KEYCODE_ENTER)){
                    pinviewstr = pinview.getText().toString();
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(pinview.getWindowToken(),0);

                    if(pinviewstr.length() == 8)
                    {
                        anim.setVisibility(View.VISIBLE);
                        anim.setImageResource(R.drawable.rite);
                        anim.startAnimation(animFadeOut);
                        Log.i(TAG,"Access Granted");

                    }else
                    {
                        Log.i(TAG,"Sorry");
                        anim.setVisibility(View.VISIBLE);
                        anim.setImageResource(R.drawable.wrong);
                        anim.startAnimation(animFadeOut);

                    }
                    return true;
                }
                return false;
            }
        });
    }


    private Bitmap getCircularBitmap(Bitmap bitmap) {

        Bitmap output;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            output = Bitmap.createBitmap(bitmap.getHeight(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        } else {
            output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getWidth(), Bitmap.Config.ARGB_8888);
        }

        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());

        float r = 0;

        if (bitmap.getWidth() > bitmap.getHeight()) {
            r = bitmap.getHeight() / 2;
        } else {
            r = bitmap.getWidth() / 2;
        }

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawCircle(r, r, r, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }

    @Override
    public void onAnimationStart(Animation animation) {

    }

    @Override
    public void onAnimationEnd(Animation animation) {

    }

    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}
